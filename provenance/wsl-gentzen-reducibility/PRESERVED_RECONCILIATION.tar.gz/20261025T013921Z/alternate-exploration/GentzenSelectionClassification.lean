module

public import DosenPetric.GentzenReducibleSites

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen
universe u
variable {P : Type u}

namespace G
variable {Γ Δ : List (NormalForm P)}

theorem leaf_predecessors_nil (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (x : Place s Γ Δ C) (h : g.Leaf s x) : g.predecessors s x = [] :=
  List.length_eq_zero_iff.mp ((g.sourceArity_correct s x).trans h)

/-- Actual positional evidence, not just the name of an ancestry class. -/
inductive SelectedRole (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (x : Place s Γ Δ C) : Type u where
  | leaf : g.Leaf s x → g.predecessors s x = [] → SelectedRole g s x
  | parametric (a : Upper g s C) :
      g.predecessors s x = [a] → g.IsPredecessor s x a → SelectedRole g s x
  | contraction : g.LowerContraction s x →
      2 ≤ (g.predecessors s x).length → SelectedRole g s x

theorem selectedRole_exists (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (x : Place s Γ Δ C) : Nonempty (SelectedRole g s x) := by
  cases g.position_classification s x with
  | inl h => exact ⟨.leaf h (g.leaf_predecessors_nil s x h)⟩
  | inr h => cases h with
    | inl h =>
      obtain ⟨a,ha,_⟩ := g.parametric_unique s x h
      refine ⟨.parametric a ha ((g.predecessors_correct s x a).mp ?_)⟩
      rw [ha]
      exact List.mem_cons_self
    | inr h =>
      refine ⟨.contraction h ?_⟩
      rw [g.sourceArity_correct]
      exact (g.lowerContraction_iff_arity s x).mp h

noncomputable def selectedRoles (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P} :
    List (Place s Γ Δ C) → List (Σ x : Place s Γ Δ C, SelectedRole g s x)
  | [] => []
  | x::xs => ⟨x,Classical.choice (g.selectedRole_exists s x)⟩ :: g.selectedRoles s xs

theorem selectedRoles_complete (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) : (g.selectedRoles s xs).map Sigma.fst = xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simpa only [selectedRoles,List.map_cons] using congrArg (List.cons x) ih

def selectionUpper (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) : List (Upper g s C) := xs.flatMap (g.predecessors s)

theorem selectionUpper_correct (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) (a : Upper g s C) :
    a ∈ g.selectionUpper s xs ↔ ∃ x ∈ xs, g.IsPredecessor s x a := by
  simp only [selectionUpper,List.mem_flatMap,g.predecessors_correct]

def selectionBranch (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) (b : Nat) : List (Upper g s C) :=
  (g.selectionUpper s xs).filter (fun a => a.branch.occurrence.branch == b)

theorem selectionBranch_correct (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) (b : Nat) (a : Upper g s C) :
    a ∈ g.selectionBranch s xs b ↔
      (∃ x ∈ xs, g.IsPredecessor s x a) ∧ a.branch.occurrence.branch = b := by
  simp [selectionBranch,selectionUpper_correct]

/-- Unary parametric, selected leaf, or selected retained-contraction regime.
The constructor witnesses the actual selected position and independent rule class. -/
inductive SelectionRegime (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) : Type u where
  | parametric : (∀ x ∈ xs, g.Parametric s x) → SelectionRegime g s xs
  | introduced (x : Place s Γ Δ C) : x ∈ xs → g.Leaf s x → SelectionRegime g s xs
  | shared (x : Place s Γ Δ C) : x ∈ xs → g.LowerContraction s x → SelectionRegime g s xs

theorem selectionRegime_exists (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) : Nonempty (SelectionRegime g s xs) := by
  classical
  by_cases hl : ∃ x ∈ xs, g.Leaf s x
  · obtain ⟨x,hx,hl⟩ := hl
    exact ⟨.introduced x hx hl⟩
  · by_cases hc : ∃ x ∈ xs, g.LowerContraction s x
    · obtain ⟨x,hx,hc⟩ := hc
      exact ⟨.shared x hx hc⟩
    · refine ⟨.parametric ?_⟩
      intro x hx
      cases g.position_classification s x with
      | inl h => exact False.elim (hl ⟨x,hx,h⟩)
      | inr h => cases h with
        | inl h => exact h
        | inr h => exact False.elim (hc ⟨x,hx,h⟩)

end G

namespace Premise
theorem branch_zero_or_one {Γ Δ Θ Λ : List (NormalForm P)} {f : G P Γ Δ} {g : G P Θ Λ}
    (a : Premise f g) : a.branch = 0 ∨ a.branch = 1 := by cases a <;> simp [branch]
end Premise

/-- Exact branch support, including the possible principal-only boundary. -/
inductive BranchSupport where
  | neither | first | second | both
  deriving DecidableEq

namespace G
variable {Γ Δ : List (NormalForm P)}

def branchSupport (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) : BranchSupport :=
  if (g.selectionBranch s xs 0).isEmpty then
    if (g.selectionBranch s xs 1).isEmpty then .neither else .second
  else if (g.selectionBranch s xs 1).isEmpty then .first else .both

theorem branchSupport_first (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) :
    (g.branchSupport s xs = .first ∨ g.branchSupport s xs = .both) ↔
      ∃ a : Upper g s C, (∃ x ∈ xs, g.IsPredecessor s x a) ∧ a.branch.occurrence.branch = 0 := by
  have he : (g.selectionBranch s xs 0).isEmpty = false ↔ ∃ a, a ∈ g.selectionBranch s xs 0 := by
    cases h : g.selectionBranch s xs 0 <;> simp
  simp only [selectionBranch_correct] at he
  rw [← he]
  unfold branchSupport
  split <;> split <;> simp_all

theorem branchSupport_second (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) :
    (g.branchSupport s xs = .second ∨ g.branchSupport s xs = .both) ↔
      ∃ a : Upper g s C, (∃ x ∈ xs, g.IsPredecessor s x a) ∧ a.branch.occurrence.branch = 1 := by
  have he : (g.selectionBranch s xs 1).isEmpty = false ↔ ∃ a, a ∈ g.selectionBranch s xs 1 := by
    cases h : g.selectionBranch s xs 1 <;> simp
  simp only [selectionBranch_correct] at he
  rw [← he]
  unfold branchSupport
  split <;> split <;> simp_all

theorem branchSupport_neither (g : G P Γ Δ) (s : SequentSide) {C : NormalForm P}
    (xs : List (Place s Γ Δ C)) :
    g.branchSupport s xs = .neither ↔ ∀ x ∈ xs, g.Leaf s x := by
  constructor
  · intro h x hx
    apply (g.leaf_iff_no_predecessor s x).mpr
    intro a ha
    have hp := ha
    cases a.branch.occurrence.branch_zero_or_one with
    | inl hb =>
      have hs := (g.branchSupport_first s xs).mpr ⟨a,⟨x,hx,hp⟩,hb⟩
      rw [h] at hs
      cases hs <;> contradiction
    | inr hb =>
      have hs := (g.branchSupport_second s xs).mpr ⟨a,⟨x,hx,hp⟩,hb⟩
      rw [h] at hs
      cases hs <;> contradiction
  · intro h
    have he : g.selectionUpper s xs = [] := by
      simp only [selectionUpper,List.flatMap_eq_nil_iff]
      intro x hx
      exact g.leaf_predecessors_nil s x (h x hx)
    simp only [branchSupport,selectionBranch,he,List.filter_nil,List.isEmpty_nil,ite_true]

end G
end DosenPetric.Reduced.Gentzen
