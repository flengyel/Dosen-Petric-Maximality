module

public import DosenPetric.GentzenBlockedExamples

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen.BlockedExamples
universe u
variable {P : Type u}

def nestedL (l : Literal P) :=
  G.contractL (.lit l) [[],[]] [] [.lit l] (Nat.le_refl 2)
    (G.thinL [] [.lit l] [.lit l] (.lit l) (unblockedL l))

def outerSiteL (l : Literal P) : ContractionSite (nestedL l) .left (.lit l) :=
  ⟨_,_,nestedL l,.root,.here (.lit l) [],.left (.lit l) [[],[]] [] [.lit l] (Nat.le_refl 2) _⟩

def innerSiteL (l : Literal P) : ContractionSite (nestedL l) .left (.lit l) :=
  ⟨_,_,unblockedL l,
    (ProofAddress.root.down (Premise.contractL (.lit l) [[],[]] [] [.lit l] (Nat.le_refl 2) _)).down
      (Premise.thinL [] [.lit l] [.lit l] (.lit l) (unblockedL l)),
    .here (.lit l) [],(siteL l).contraction⟩

theorem nested_properL (l : Literal P) : (outerSiteL l).ProperContains (innerSiteL l) :=
  ⟨(innerSiteL l).address,ProofAddress.root_append _,by intro h; cases h⟩

def nestedR (l : Literal P) :=
  G.contractR [.lit l] (.lit l) [[],[]] [] (Nat.le_refl 2)
    (G.thinR [.lit l] [] [.lit l] (.lit l) (unblockedR l))

def outerSiteR (l : Literal P) : ContractionSite (nestedR l) .right (.lit l) :=
  ⟨_,_,nestedR l,.root,.here (.lit l) [],.right [.lit l] (.lit l) [[],[]] [] (Nat.le_refl 2) _⟩

def innerSiteR (l : Literal P) : ContractionSite (nestedR l) .right (.lit l) :=
  ⟨_,_,unblockedR l,
    (ProofAddress.root.down (Premise.contractR [.lit l] (.lit l) [[],[]] [] (Nat.le_refl 2) _)).down
      (Premise.thinR [.lit l] [] [.lit l] (.lit l) (unblockedR l)),
    .here (.lit l) [],(siteR l).contraction⟩

theorem nested_properR (l : Literal P) : (outerSiteR l).ProperContains (innerSiteR l) :=
  ⟨(innerSiteR l).address,ProofAddress.root_append _,by intro h; cases h⟩

def duplicateFirst (l : Literal P) : ContractionSite (G.mix (unblockedL l) (unblockedL l)) .left (.lit l) :=
  ⟨_,_,unblockedL l,.root.down (Premise.mix_left _ _),.here (.lit l) [],(siteL l).contraction⟩
def duplicateSecond (l : Literal P) : ContractionSite (G.mix (unblockedL l) (unblockedL l)) .left (.lit l) :=
  ⟨_,_,unblockedL l,.root.down (Premise.mix_right _ _),.here (.lit l) [],(siteL l).contraction⟩

theorem duplicate_paths (l : Literal P) :
    (duplicateFirst l).proof = (duplicateSecond l).proof ∧
    (duplicateFirst l).address.path ≠ (duplicateSecond l).address.path ∧
    ¬ (duplicateFirst l).ProperContains (duplicateSecond l) := by
  refine ⟨rfl,?_,?_⟩
  · intro h; cases h
  · intro h
    have hh := (duplicateFirst l).proper_path_length (duplicateSecond l) h
    change 1 < 1 at hh
    omega

def firstOnly (C : NormalForm P) : ContractionBlock P [C,C,C] [C,C] :=
  ⟨C,[[C],[]],[],rfl,rfl⟩
def secondOnly (C : NormalForm P) : ContractionBlock P [C,C,C] [C,C] :=
  ⟨C,[[],[]],[C],rfl,rfl⟩

theorem first_branch_selected (l : Literal P) :
    (G.mix (thinPremiseL l) (G.identity l)).branchSupport .left (firstOnly (.lit l)).selected = .first := rfl

theorem second_branch_selected (l : Literal P) :
    (G.mix (G.identity l) (thinPremiseL l)).branchSupport .left (secondOnly (.lit l)).selected = .second := rfl

def compoundPrincipal (l : Literal P) :=
  G.conjR (G.thinR [.lit l] [.lit l] [] (.conj (.lit l) (.lit l)) (G.identity l)) (G.identity l)

theorem compound_principal_leaf (l : Literal P) :
    (compoundPrincipal l).predecessors .right
      (.here (.conj (.lit l) (.lit l)) [.conj (.lit l) (.lit l)]) = [] :=
  (compoundPrincipal l).leaf_predecessors_nil .right _ rfl

theorem compound_principal_and_first (l : Literal P) :
    (compoundPrincipal l).branchSupport .right (two (.conj (.lit l) (.lit l))).selected = .first := rfl

theorem complete_ordered_roles (l : Literal P) :
    ((firstOnly (.lit l)).classifyL (Nat.le_refl 2) _
      (G.mix (thinPremiseL l) (G.identity l)) rfl).roles.map Sigma.fst =
      (firstOnly (.lit l)).selected :=
  ((firstOnly (.lit l)).classifyL (Nat.le_refl 2) _ _ rfl).complete

end DosenPetric.Reduced.Gentzen.BlockedExamples
