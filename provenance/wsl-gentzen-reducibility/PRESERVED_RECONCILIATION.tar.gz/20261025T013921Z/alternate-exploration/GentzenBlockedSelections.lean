module

public import DosenPetric.GentzenBlockedSourceRules

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen
universe u
variable {P : Type u}

/-- The seven source blocked selections, in the repository's actual rule order.
The list contains exactly the displayed upper contraction occurrences. -/
inductive BlockedSelectionL : {Γ Δ : List (NormalForm P)} → (g : G P Γ Δ) →
    {C : NormalForm P} → List (At Γ C) → Prop where
  | mix {Γ Θ Δ Λ C} (f : G P Γ Δ) (g : G P Θ Λ) (x : At Γ C) (y : At Θ C) :
      BlockedSelectionL (G.mix f g) [y.before Γ,At.shift Θ x]
  | conjR {Γ Θ Δ Λ A B C} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ))
      (x : At Γ C) (y : At Θ C) :
      BlockedSelectionL (G.conjR f g) [x.before Θ,At.shift Γ y]
  | disjL_parametric {Γ Θ Δ Λ A B C} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ)
      (x : At Γ C) (y : At Θ C) :
      BlockedSelectionL (SourceRules.disjL f g)
        [(x.before Θ).before [.disj A B],(At.shift Γ y).before [.disj A B]]
  | conjL {Γ Δ A B} (f : G P (Γ++[A,B]) Δ) (x : At Γ (.conj A B)) :
      BlockedSelectionL (G.conjL Γ [] Δ A B f)
        [x.before [.conj A B],At.shift Γ (.here (.conj A B) [])]
  | disjL_first {Γ Θ Δ Λ A B} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ)
      (x : At Γ (.disj A B)) :
      BlockedSelectionL (SourceRules.disjL f g)
        [(x.before Θ).before [.disj A B],At.shift (Γ++Θ) (.here (.disj A B) [])]
  | disjL_second {Γ Θ Δ Λ A B} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ)
      (y : At Θ (.disj A B)) :
      BlockedSelectionL (SourceRules.disjL f g)
        [(At.shift Γ y).before [.disj A B],At.shift (Γ++Θ) (.here (.disj A B) [])]
  | disjL_both {Γ Θ Δ Λ A B} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ)
      (x : At Γ (.disj A B)) (y : At Θ (.disj A B)) :
      BlockedSelectionL (SourceRules.disjL f g)
        [(x.before Θ).before [.disj A B],(At.shift Γ y).before [.disj A B],
          At.shift (Γ++Θ) (.here (.disj A B) [])]

/-- Separately typed right analogues; no arrow-negation operation is used. -/
inductive BlockedSelectionR : {Γ Δ : List (NormalForm P)} → (g : G P Γ Δ) →
    {C : NormalForm P} → List (At Δ C) → Prop where
  | mix {Γ Θ Δ Λ C} (f : G P Γ Δ) (g : G P Θ Λ) (x : At Δ C) (y : At Λ C) :
      BlockedSelectionR (G.mix f g) [y.before Δ,At.shift Λ x]
  | disjL {Γ Θ Δ Λ A B C} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ)
      (x : At Δ C) (y : At Λ C) :
      BlockedSelectionR (G.disjL f g) [x.before Λ,At.shift Δ y]
  | conjR_parametric {Γ Θ Δ Λ A B C} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ))
      (x : At Δ C) (y : At Λ C) :
      BlockedSelectionR (SourceRules.conjR f g)
        [(x.before Λ).before [.conj A B],(At.shift Δ y).before [.conj A B]]
  | disjR {Γ Δ A B} (f : G P Γ (Δ++[A,B])) (x : At Δ (.disj A B)) :
      BlockedSelectionR (G.disjR Γ Δ [] A B f)
        [x.before [.disj A B],At.shift Δ (.here (.disj A B) [])]
  | conjR_first {Γ Θ Δ Λ A B} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ))
      (x : At Δ (.conj A B)) :
      BlockedSelectionR (SourceRules.conjR f g)
        [(x.before Λ).before [.conj A B],At.shift (Δ++Λ) (.here (.conj A B) [])]
  | conjR_second {Γ Θ Δ Λ A B} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ))
      (y : At Λ (.conj A B)) :
      BlockedSelectionR (SourceRules.conjR f g)
        [(At.shift Δ y).before [.conj A B],At.shift (Δ++Λ) (.here (.conj A B) [])]
  | conjR_both {Γ Θ Δ Λ A B} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ))
      (x : At Δ (.conj A B)) (y : At Λ (.conj A B)) :
      BlockedSelectionR (SourceRules.conjR f g)
        [(x.before Λ).before [.conj A B],(At.shift Δ y).before [.conj A B],
          At.shift (Δ++Λ) (.here (.conj A B) [])]

theorem blockedSelectionL_length {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Γ C)} (h : BlockedSelectionL g xs) :
    xs.length = 2 ∨ xs.length = 3 := by cases h <;> simp

theorem blockedSelectionR_length {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Δ C)} (h : BlockedSelectionR g xs) :
    xs.length = 2 ∨ xs.length = 3 := by cases h <;> simp

/-- A blocked term is an actual contraction with exactly a source blocked selection. -/
def BlockedL : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Prop
  | _,_,.contractL C gs Θ _ _ f => BlockedSelectionL f (selectedCopies C gs Θ)
  | _,_,_ => False

def BlockedR : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Prop
  | _,_,.contractR _ C gs Λ _ f => BlockedSelectionR f (selectedCopies C gs Λ)
  | _,_,_ => False

def G.rootContractionArity : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Nat
  | _,_,.contractL _ gs _ _ _ _ | _,_,.contractR _ _ gs _ _ _ => gs.length
  | _,_,_ => 0

theorem blockedL_arity {Γ Δ : List (NormalForm P)} {g : G P Γ Δ} (h : BlockedL g) :
    g.rootContractionArity = 2 ∨ g.rootContractionArity = 3 := by
  cases g <;> try exact False.elim h
  simpa only [G.rootContractionArity,selectedCopies_length] using blockedSelectionL_length h

theorem blockedR_arity {Γ Δ : List (NormalForm P)} {g : G P Γ Δ} (h : BlockedR g) :
    g.rootContractionArity = 2 ∨ g.rootContractionArity = 3 := by
  cases g <;> try exact False.elim h
  simpa only [G.rootContractionArity,selectedCopies_length] using blockedSelectionR_length h

theorem blockedL_reindex {Γ Δ Γ' Δ' : List (NormalForm P)} (hΓ : Γ=Γ') (hΔ : Δ=Δ')
    (g : G P Γ Δ) : BlockedL (g.reindex hΓ hΔ) ↔ BlockedL g := by cases hΓ; cases hΔ; rfl

theorem blockedR_reindex {Γ Δ Γ' Δ' : List (NormalForm P)} (hΓ : Γ=Γ') (hΔ : Δ=Δ')
    (g : G P Γ Δ) : BlockedR (g.reindex hΓ hΔ) ↔ BlockedR g := by cases hΓ; cases hΔ; rfl

end DosenPetric.Reduced.Gentzen
