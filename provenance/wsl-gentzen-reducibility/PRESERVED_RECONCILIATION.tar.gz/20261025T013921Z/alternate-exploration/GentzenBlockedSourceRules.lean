module

public import DosenPetric.GentzenProofReplacement
public import DosenPetric.GentzenContractionBlocks

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen.SourceRules
universe u
variable {P : Type u}

theorem principalUpper (D : NormalForm P) (L : List (NormalForm P)) :
    D::L = []++[D]++L++[] := by simp

theorem principalLower (D : NormalForm P) (L : List (NormalForm P)) :
    []++L++[D]++[] = L++[D] := by simp

/-- The source's principal-last disjunction-left rule, derived by actual exchange. -/
def disjL {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ) : G P ((Γ++Θ)++[.disj A B]) (Δ++Λ) :=
  (G.exchangeL [] [.disj A B] (Γ++Θ) [] (Δ++Λ)
    ((G.disjL f g).reindex (principalUpper (.disj A B) (Γ++Θ)) rfl)).reindex
      (principalLower (.disj A B) (Γ++Θ)) rfl

/-- The separately typed principal-last conjunction-right rule. -/
def conjR {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ)) : G P (Γ++Θ) ((Δ++Λ)++[.conj A B]) :=
  (G.exchangeR (Γ++Θ) [] [.conj A B] (Δ++Λ) []
    ((G.conjR f g).reindex rfl (principalUpper (.conj A B) (Δ++Λ)))).reindex
      rfl (principalLower (.conj A B) (Δ++Λ))

theorem disjL_denote {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ) :
    (disjL f g).denote = termTransport (principalLower (.disj A B) (Γ++Θ)) rfl
      (.comp (exchange .conj [] [.disj A B] (Γ++Θ) []).invTerm
        (termTransport (principalUpper (.disj A B) (Γ++Θ)) rfl (Rules.disjLeft f.denote g.denote))) := by
  simp only [disjL,G.denote_reindex,G.denote]

theorem conjR_denote {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ)) :
    (conjR f g).denote = termTransport rfl (principalLower (.conj A B) (Δ++Λ))
      (.comp (termTransport rfl (principalUpper (.conj A B) (Δ++Λ)) (Rules.conjRight f.denote g.denote))
        (exchange .disj [] [.conj A B] (Δ++Λ) []).toTerm) := by
  simp only [conjR,G.denote_reindex,G.denote]

theorem disjL_cutCount {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ) : (disjL f g).cutCount = f.cutCount+g.cutCount := by
  simp only [disjL,G.count_reindex,G.cutCount]

theorem conjR_cutCount {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ)) : (conjR f g).cutCount = f.cutCount+g.cutCount := by
  simp only [conjR,G.count_reindex,G.cutCount]

theorem disjL_atomized {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ) : (disjL f g).Atomized ↔ f.Atomized ∧ g.Atomized := by
  simp only [disjL,G.atomized_reindex,G.Atomized]

theorem conjR_atomized {Γ Θ Δ Λ : List (NormalForm P)} {A B : NormalForm P}
    (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ)) : (conjR f g).Atomized ↔ f.Atomized ∧ g.Atomized := by
  simp only [conjR,G.atomized_reindex,G.Atomized]

end DosenPetric.Reduced.Gentzen.SourceRules
