module

public import DosenPetric.GentzenImmediateClassification

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen
universe u
variable {P : Type u}

namespace At

def beforeList : {Γ : List (NormalForm P)} → {C : NormalForm P} → At Γ C → List (NormalForm P)
  | _,_,.here .. => []
  | B::_,_,.there a => B::a.beforeList

def suffix : {Γ : List (NormalForm P)} → {C : NormalForm P} → At Γ C → List (NormalForm P)
  | _,_,.here _ Θ => Θ
  | _,_,.there a => a.suffix

theorem decomposition {Γ : List (NormalForm P)} {C : NormalForm P} (a : At Γ C) :
    Γ = a.beforeList ++ C::a.suffix := by
  induction a with
  | here => rfl
  | @there A B Γ a ih => exact congrArg (List.cons B) ih

theorem beforeList_length {Γ : List (NormalForm P)} {C : NormalForm P} (a : At Γ C) :
    a.beforeList.length = a.index := by
  induction a with
  | here => rfl
  | there a ih => exact congrArg Nat.succ ih

theorem decomposition_position {Γ : List (NormalForm P)} {C : NormalForm P} (a : At Γ C) :
    a.cast a.decomposition = At.shift a.beforeList (.here C a.suffix) := by
  apply At.index_injective
  simp only [At.index_cast,At.index_shift,At.index,Nat.add_zero,a.beforeList_length]

end At

namespace G

def blockingPremiseL : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Bool
  | _,_,.mix .. | _,_,.conjR .. | _,_,.exchangeL .. | _,_,.conjL .. => true
  | _,_,_ => false

def blockingPremiseR : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Bool
  | _,_,.mix .. | _,_,.disjL .. | _,_,.exchangeR .. | _,_,.disjR .. => true
  | _,_,_ => false

end G

theorem blockedSelectionL_head {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Γ C)} (h : BlockedSelectionL g xs) :
    g.blockingPremiseL = true := by cases h <;> rfl

theorem blockedSelectionR_head {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Δ C)} (h : BlockedSelectionR g xs) :
    g.blockingPremiseR = true := by cases h <;> rfl

/-- All blocked selections are strictly ordered, including when labels coincide. -/
theorem blockedSelectionL_ordered {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Γ C)} (h : BlockedSelectionL g xs) : At.Ordered xs := by
  cases h with
  | mix f g x y =>
    have hy := y.index_lt
    simp [At.Ordered,At.index_before,At.index_shift]
    omega
  | conjR f g x y =>
    have hx := x.index_lt
    simp [At.Ordered,At.index_before,At.index_shift]
    omega
  | disjL_parametric f g x y =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | conjL f x =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    exact hx
  | disjL_first f g x =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | disjL_second f g y =>
    have hy := y.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | disjL_both f g x y =>
    have hx := x.index_lt
    have hy := y.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega

theorem blockedSelectionR_ordered {Γ Δ : List (NormalForm P)} {g : G P Γ Δ}
    {C : NormalForm P} {xs : List (At Δ C)} (h : BlockedSelectionR g xs) : At.Ordered xs := by
  cases h with
  | mix f g x y =>
    have hy := y.index_lt
    simp [At.Ordered,At.index_before,At.index_shift]
    omega
  | disjL f g x y =>
    have hx := x.index_lt
    simp [At.Ordered,At.index_before,At.index_shift]
    omega
  | conjR_parametric f g x y =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | disjR f x =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    exact hx
  | conjR_first f g x =>
    have hx := x.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | conjR_second f g y =>
    have hy := y.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega
  | conjR_both f g x y =>
    have hx := x.index_lt
    have hy := y.index_lt
    simp [At.Ordered,At.index,At.index_before,At.index_shift]
    omega

namespace ContractionBlock
variable {U K : List (NormalForm P)} (d : ContractionBlock P U K)

theorem blockedL_iff (hn : 2 ≤ d.gs.length) (Δ : List (NormalForm P)) (f : G P U Δ) :
    BlockedL (d.applyL hn Δ f) ↔ BlockedSelectionL f d.selected := by
  obtain ⟨C,gs,tail,hu,hl⟩ := d
  cases hu
  cases hl
  change BlockedSelectionL f (selectedCopies C gs tail) ↔
    BlockedSelectionL f ((selectedCopies C gs tail).map (fun a => a))
  simp

theorem blockedR_iff (hn : 2 ≤ d.gs.length) (Γ : List (NormalForm P)) (f : G P Γ U) :
    BlockedR (d.applyR hn Γ f) ↔ BlockedSelectionR f d.selected := by
  obtain ⟨C,gs,tail,hu,hl⟩ := d
  cases hu
  cases hl
  change BlockedSelectionR f (selectedCopies C gs tail) ↔
    BlockedSelectionR f ((selectedCopies C gs tail).map (fun a => a))
  simp

end ContractionBlock
end DosenPetric.Reduced.Gentzen
