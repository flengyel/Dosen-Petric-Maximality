module

public import DosenPetric.GentzenSelectionClassification

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen
universe u
variable {P : Type u}

/-- The actual rule, premises and all indices, with bases and cut excluded. -/
inductive HeadView : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Type u where
  | exchangeL (Γ X Y Θ Δ) (f : G P (Γ++X++Y++Θ) Δ) : HeadView (G.exchangeL Γ X Y Θ Δ f)
  | exchangeR (Γ Δ X Y Λ) (f : G P Γ (Δ++X++Y++Λ)) : HeadView (G.exchangeR Γ Δ X Y Λ f)
  | thinL (Γ Θ Δ A) (f : G P (Γ++Θ) Δ) : HeadView (G.thinL Γ Θ Δ A f)
  | thinR (Γ Δ Λ A) (f : G P Γ (Δ++Λ)) : HeadView (G.thinR Γ Δ Λ A f)
  | contractL (C gs Θ Δ hn) (f : G P (repeated C gs++Θ) Δ) : HeadView (G.contractL C gs Θ Δ hn f)
  | contractR (Γ C gs Λ hn) (f : G P Γ (repeated C gs++Λ)) : HeadView (G.contractR Γ C gs Λ hn f)
  | conjL (Γ Θ Δ A B) (f : G P (Γ++A::B::Θ) Δ) : HeadView (G.conjL Γ Θ Δ A B f)
  | disjR (Γ Δ Λ A B) (f : G P Γ (Δ++A::B::Λ)) : HeadView (G.disjR Γ Δ Λ A B f)
  | conjR {Γ Θ Δ Λ A B} (f : G P Γ (A::Δ)) (g : G P Θ (B::Λ)) : HeadView (G.conjR f g)
  | disjL {Γ Θ Δ Λ A B} (f : G P (A::Γ) Δ) (g : G P (B::Θ) Λ) : HeadView (G.disjL f g)
  | mix {Γ Θ Δ Λ} (f : G P Γ Δ) (g : G P Θ Λ) : HeadView (G.mix f g)

namespace G
variable {Γ Δ : List (NormalForm P)}

theorem headView_exists (g : G P Γ Δ) (s : SequentSide)
    (hc : g.CutFree) (hl : 2 ≤ (s.context Γ Δ).length) : Nonempty (HeadView g) := by
  cases g with
  | identity l => cases s <;> simp [SequentSide.context] at hl
  | zero l => cases s <;> simp [SequentSide.context] at hl
  | topI => cases s <;> simp [SequentSide.context] at hl
  | botE => cases s <;> simp [SequentSide.context] at hl
  | exchangeL => exact ⟨.exchangeL ..⟩
  | exchangeR => exact ⟨.exchangeR ..⟩
  | thinL => exact ⟨.thinL ..⟩
  | thinR => exact ⟨.thinR ..⟩
  | contractL => exact ⟨.contractL ..⟩
  | contractR => exact ⟨.contractR ..⟩
  | conjL => exact ⟨.conjL ..⟩
  | disjR => exact ⟨.disjR ..⟩
  | conjR => exact ⟨.conjR ..⟩
  | disjL => exact ⟨.disjL ..⟩
  | mix => exact ⟨.mix ..⟩
  | cut f g => exact False.elim (cut_not_cutFree f g hc)

def isBinary : {Γ Δ : List (NormalForm P)} → G P Γ Δ → Bool
  | _,_,.conjR .. | _,_,.disjL .. | _,_,.mix .. | _,_,.cut .. => true
  | _,_,_ => false

theorem binary_leaf_indices (g : G P Γ Δ) (s : SequentSide) (hb : g.isBinary = true)
    {C : NormalForm P} (x y : Place s Γ Δ C) (hx : g.Leaf s x) (hy : g.Leaf s y) :
    x.index = y.index := by
  cases g <;> cases s <;> simp_all [isBinary,Leaf,sourceArity]
  all_goals split at hx <;> split at hy <;> omega

theorem binary_support_nonempty (g : G P Γ Δ) (s : SequentSide) (hb : g.isBinary = true)
    {C : NormalForm P} (xs : List (Place s Γ Δ C)) (ho : At.Ordered xs)
    (hn : 2 ≤ xs.length) : g.branchSupport s xs ≠ .neither := by
  intro he
  have hl := (g.branchSupport_neither s xs).mp he
  cases xs with
  | nil => simp at hn
  | cons a xs => cases xs with
    | nil => simp at hn
    | cons b bs =>
      have hab := List.rel_of_pairwise_cons ho (List.mem_cons_self (a := b) (l := bs))
      have ha := hl a List.mem_cons_self
      have hb' := hl b (List.mem_cons_of_mem a List.mem_cons_self)
      have hi := g.binary_leaf_indices s hb a b ha hb'
      omega

end G

/-- Finite classification retaining every selected tag, its actual predecessors,
and the exact two-branch support. No rewrite or rank conclusion is stored. -/
structure ImmediateClassification {Γ Δ : List (NormalForm P)} (g : G P Γ Δ)
    (s : SequentSide) {C : NormalForm P} (xs : List (Place s Γ Δ C)) where
  head : HeadView g
  roles : List (Σ x : Place s Γ Δ C, g.SelectedRole s x)
  complete : roles.map Sigma.fst = xs
  regime : g.SelectionRegime s xs
  support : BranchSupport
  support_correct : support = g.branchSupport s xs
  binary_nonempty : g.isBinary = true → support ≠ .neither

theorem repeated_count_le (C : NormalForm P) (gs : List (List (NormalForm P))) :
    gs.length ≤ (repeated C gs).length := by
  induction gs with
  | nil => simp [repeated]
  | cons Γ gs ih => simp only [repeated,List.length_cons,List.length_append]; omega

namespace ContractionBlock
variable {U K : List (NormalForm P)} (d : ContractionBlock P U K)

theorem upper_length (hn : 2 ≤ d.gs.length) : 2 ≤ U.length := by
  have h := repeated_count_le d.C d.gs
  have he := congrArg List.length d.upper
  simp only [List.length_append] at he
  omega

noncomputable def classifyL (hn : 2 ≤ d.gs.length) (Δ : List (NormalForm P))
    (f : G P U Δ) (hc : f.CutFree) : ImmediateClassification f .left d.selected where
  head := Classical.choice (f.headView_exists .left hc (d.upper_length hn))
  roles := f.selectedRoles .left d.selected
  complete := f.selectedRoles_complete .left d.selected
  regime := Classical.choice (f.selectionRegime_exists .left d.selected)
  support := f.branchSupport .left d.selected
  support_correct := rfl
  binary_nonempty hb := f.binary_support_nonempty .left hb d.selected d.selected_ordered
    (d.selected_length.symm ▸ hn)

noncomputable def classifyR (hn : 2 ≤ d.gs.length) (Γ : List (NormalForm P))
    (f : G P Γ U) (hc : f.CutFree) : ImmediateClassification f .right d.selected where
  head := Classical.choice (f.headView_exists .right hc (d.upper_length hn))
  roles := f.selectedRoles .right d.selected
  complete := f.selectedRoles_complete .right d.selected
  regime := Classical.choice (f.selectionRegime_exists .right d.selected)
  support := f.branchSupport .right d.selected
  support_correct := rfl
  binary_nonempty hb := f.binary_support_nonempty .right hb d.selected d.selected_ordered
    (d.selected_length.symm ▸ hn)

theorem classifiedL_count (hn : 2 ≤ d.gs.length) (Δ : List (NormalForm P))
    (f : G P U Δ) (hc : f.CutFree) : (d.classifyL hn Δ f hc).roles.length = d.gs.length := by
  have h := congrArg List.length (d.classifyL hn Δ f hc).complete
  simp only [List.length_map] at h
  exact h.trans d.selected_length

theorem classifiedR_count (hn : 2 ≤ d.gs.length) (Γ : List (NormalForm P))
    (f : G P Γ U) (hc : f.CutFree) : (d.classifyR hn Γ f hc).roles.length = d.gs.length := by
  have h := congrArg List.length (d.classifyR hn Γ f hc).complete
  simp only [List.length_map] at h
  exact h.trans d.selected_length

end ContractionBlock
end DosenPetric.Reduced.Gentzen
