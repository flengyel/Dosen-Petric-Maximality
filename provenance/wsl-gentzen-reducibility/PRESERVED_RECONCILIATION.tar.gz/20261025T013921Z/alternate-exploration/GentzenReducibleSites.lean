module

public import DosenPetric.GentzenBlockedSelections

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen
universe u
variable {P : Type u}

/-- A particular contraction occurrence and its actual retained formula position. -/
structure ContractionSite {Γ Δ : List (NormalForm P)} (root : G P Γ Δ)
    (s : SequentSide) (C : NormalForm P) where
  source : List (NormalForm P)
  target : List (NormalForm P)
  proof : G P source target
  address : ProofAddress root proof
  position : Place s source target C
  contraction : proof.LowerContraction s position

namespace ContractionSite
variable {Γ Δ : List (NormalForm P)} {root : G P Γ Δ} {s : SequentSide} {C : NormalForm P}

def node (a : ContractionSite root s C) : TraceNode P s C :=
  ⟨a.source,a.target,a.proof,a.address.path,a.position⟩

theorem node_valid (a : ContractionSite root s C) : a.node.Valid root := ⟨a.address,rfl⟩

/-- Containment at the actual occurrence path, excluding the hole itself. -/
def ProperContains (a b : ContractionSite root s C) : Prop :=
  ∃ c : ProofAddress a.proof b.proof, a.address.append c = b.address ∧ c.path ≠ []

theorem proper_path_length (a b : ContractionSite root s C) (h : a.ProperContains b) :
    a.address.path.length < b.address.path.length := by
  obtain ⟨c,hc,hn⟩ := h
  have hp := congrArg (fun d => d.path.length) hc
  rw [ProofAddress.append_path,List.length_append] at hp
  have hn' : 0 < c.path.length := List.length_pos_iff.mpr hn
  omega

theorem not_proper_self (a : ContractionSite root s C) : ¬ a.ProperContains a := by
  intro h
  have hp := proper_path_length a a h
  omega

theorem proper_trans (a b c : ContractionSite root s C)
    (hab : a.ProperContains b) (hbc : b.ProperContains c) : a.ProperContains c := by
  obtain ⟨x,hx,hnx⟩ := hab
  obtain ⟨y,hy,hny⟩ := hbc
  refine ⟨x.append y,?_,?_⟩
  · rw [← ProofAddress.append_assoc,hx,hy]
  · rw [ProofAddress.append_path]
    intro h
    have hh := congrArg List.length h
    simp only [List.length_append,List.length_nil] at hh
    have hx' : 0 < x.path.length := List.length_pos_iff.mpr hnx
    omega

theorem proper_asymm (a b : ContractionSite root s C) (h : a.ProperContains b) :
    ¬ b.ProperContains a := fun h' => a.not_proper_self (proper_trans a b a h h')

theorem cutFree (a : ContractionSite root s C) (hr : root.CutFree) : a.proof.CutFree := a.address.cutFree hr

theorem atomized (a : ContractionSite root s C) (hr : root.Atomized) : a.proof.Atomized := a.address.atomized hr

end ContractionSite

/-- Source p.250: an unblocked tied left contraction whose proper containing
tied left contractions are blocked. No reduct or rank claim is a field. -/
structure ReducibleRight {Γ Θ Δ Λ : List (NormalForm P)} {C : NormalForm P}
    (f : G P Γ (C::Δ)) (g : G P (C::Θ) Λ) (a : ContractionSite g .left C) : Prop where
  topmost : G.Topmost f g
  tied : g.TiedRight a.node
  unblocked : ¬ BlockedL a.proof
  ancestors : ∀ b : ContractionSite g .left C,
    g.TiedRight b.node → b.ProperContains a → BlockedL b.proof

/-- Independently typed right-contraction analogue in the left cut premise. -/
structure ReducibleLeft {Γ Θ Δ Λ : List (NormalForm P)} {C : NormalForm P}
    (f : G P Γ (C::Δ)) (g : G P (C::Θ) Λ) (a : ContractionSite f .right C) : Prop where
  topmost : G.Topmost f g
  tied : f.TiedLeft a.node
  unblocked : ¬ BlockedR a.proof
  ancestors : ∀ b : ContractionSite f .right C,
    f.TiedLeft b.node → b.ProperContains a → BlockedR b.proof

namespace ReducibleRight
variable {Γ Θ Δ Λ : List (NormalForm P)} {C : NormalForm P}
variable {f : G P Γ (C::Δ)} {g : G P (C::Θ) Λ} {a : ContractionSite g .left C}

theorem cutFree (h : ReducibleRight f g a) : a.proof.CutFree := a.cutFree h.topmost.2
theorem no_unblocked_ancestor (h : ReducibleRight f g a) (b : ContractionSite g .left C)
    (hb : g.TiedRight b.node) (hu : ¬ BlockedL b.proof) : ¬ b.ProperContains a :=
  fun hp => hu (h.ancestors b hb hp)
end ReducibleRight

namespace ReducibleLeft
variable {Γ Θ Δ Λ : List (NormalForm P)} {C : NormalForm P}
variable {f : G P Γ (C::Δ)} {g : G P (C::Θ) Λ} {a : ContractionSite f .right C}

theorem cutFree (h : ReducibleLeft f g a) : a.proof.CutFree := a.cutFree h.topmost.1
theorem no_unblocked_ancestor (h : ReducibleLeft f g a) (b : ContractionSite f .right C)
    (hb : f.TiedLeft b.node) (hu : ¬ BlockedR b.proof) : ¬ b.ProperContains a :=
  fun hp => hu (h.ancestors b hb hp)
end ReducibleLeft

end DosenPetric.Reduced.Gentzen
