module

public import DosenPetric.GentzenBlockedPositions
public import DosenPetric.GentzenSameSideLogicalExamples

@[expose] public section
set_option autoImplicit false
namespace DosenPetric.Reduced.Gentzen.BlockedExamples
universe u
variable {P : Type u}
open W1.SameSideLogical (constantLeft constantRight)

abbrev two (C : NormalForm P) : ContractionBlock P [C,C] [C] := ⟨C,[[],[]],[],rfl,rfl⟩
abbrev three (C : NormalForm P) : ContractionBlock P [C,C,C] [C] := ⟨C,[[],[],[]],[],rfl,rfl⟩
abbrev beforeTail (D C : NormalForm P) : ContractionBlock P [C,C,D] [C,D] :=
  ⟨C,[[],[]],[D],rfl,rfl⟩

theorem gammaOneL : BlockedL ((two (.top : NormalForm Empty)).applyL (Nat.le_refl 2) _
    (G.mix (constantLeft [.top]) (constantLeft [.top]))) := by
  apply ((two (.top : NormalForm Empty)).blockedL_iff ..).mpr
  exact .mix _ _ (.here _ []) (.here _ [])

theorem gammaTwoL : BlockedL ((two (.top : NormalForm Empty)).applyL (Nat.le_refl 2) _
    (G.conjR (constantLeft [.top]) (constantLeft [.top]))) := by
  apply ((two (.top : NormalForm Empty)).blockedL_iff ..).mpr
  exact .conjR _ _ (.here _ []) (.here _ [])

theorem gammaThreeL : BlockedL ((beforeTail (.disj .top .top) (.top : NormalForm Empty)).applyL
    (Nat.le_refl 2) _ (SourceRules.disjL (constantLeft [.top,.top]) (constantLeft [.top,.top]))) := by
  apply ((beforeTail (.disj .top .top) (.top : NormalForm Empty)).blockedL_iff ..).mpr
  exact .disjL_parametric _ _ (.here _ []) (.here _ [])

theorem conjunctionL : BlockedL ((two (.conj (.top : NormalForm Empty) .top)).applyL
    (Nat.le_refl 2) _ (G.conjL [.conj .top .top] [] [.top] .top .top
      (constantLeft [.conj .top .top,.top,.top]))) := by
  apply ((two (.conj (.top : NormalForm Empty) .top)).blockedL_iff ..).mpr
  exact .conjL _ (.here _ [])

theorem disjunctionFirstL : BlockedL ((two (.disj (.top : NormalForm Empty) .top)).applyL
    (Nat.le_refl 2) _ (SourceRules.disjL (constantLeft [.top,.disj .top .top]) (constantLeft [.top]))) := by
  apply ((two (.disj (.top : NormalForm Empty) .top)).blockedL_iff ..).mpr
  exact .disjL_first _ _ (.here _ [])

theorem disjunctionSecondL : BlockedL ((two (.disj (.top : NormalForm Empty) .top)).applyL
    (Nat.le_refl 2) _ (SourceRules.disjL (constantLeft [.top]) (constantLeft [.top,.disj .top .top]))) := by
  apply ((two (.disj (.top : NormalForm Empty) .top)).blockedL_iff ..).mpr
  exact .disjL_second _ _ (.here _ [])

theorem disjunctionBothL : BlockedL ((three (.disj (.top : NormalForm Empty) .top)).applyL
    (by change 2 ≤ 3; omega) _
      (SourceRules.disjL (constantLeft [.top,.disj .top .top]) (constantLeft [.top,.disj .top .top]))) := by
  apply ((three (.disj (.top : NormalForm Empty) .top)).blockedL_iff ..).mpr
  exact .disjL_both _ _ (.here _ []) (.here _ [])

theorem gammaOneR : BlockedR ((two (.bot : NormalForm Empty)).applyR (Nat.le_refl 2) _
    (G.mix (constantRight [.bot]) (constantRight [.bot]))) := by
  apply ((two (.bot : NormalForm Empty)).blockedR_iff ..).mpr
  exact .mix _ _ (.here _ []) (.here _ [])

theorem gammaTwoR : BlockedR ((two (.bot : NormalForm Empty)).applyR (Nat.le_refl 2) _
    (G.disjL (constantRight [.bot]) (constantRight [.bot]))) := by
  apply ((two (.bot : NormalForm Empty)).blockedR_iff ..).mpr
  exact .disjL _ _ (.here _ []) (.here _ [])

theorem gammaThreeR : BlockedR ((beforeTail (.conj .bot .bot) (.bot : NormalForm Empty)).applyR
    (Nat.le_refl 2) _ (SourceRules.conjR (constantRight [.bot,.bot]) (constantRight [.bot,.bot]))) := by
  apply ((beforeTail (.conj .bot .bot) (.bot : NormalForm Empty)).blockedR_iff ..).mpr
  exact .conjR_parametric _ _ (.here _ []) (.here _ [])

theorem disjunctionR : BlockedR ((two (.disj (.bot : NormalForm Empty) .bot)).applyR
    (Nat.le_refl 2) _ (G.disjR [.bot] [.disj .bot .bot] [] .bot .bot
      (constantRight [.disj .bot .bot,.bot,.bot]))) := by
  apply ((two (.disj (.bot : NormalForm Empty) .bot)).blockedR_iff ..).mpr
  exact .disjR _ (.here _ [])

theorem conjunctionFirstR : BlockedR ((two (.conj (.bot : NormalForm Empty) .bot)).applyR
    (Nat.le_refl 2) _ (SourceRules.conjR (constantRight [.bot,.conj .bot .bot]) (constantRight [.bot]))) := by
  apply ((two (.conj (.bot : NormalForm Empty) .bot)).blockedR_iff ..).mpr
  exact .conjR_first _ _ (.here _ [])

theorem conjunctionSecondR : BlockedR ((two (.conj (.bot : NormalForm Empty) .bot)).applyR
    (Nat.le_refl 2) _ (SourceRules.conjR (constantRight [.bot]) (constantRight [.bot,.conj .bot .bot]))) := by
  apply ((two (.conj (.bot : NormalForm Empty) .bot)).blockedR_iff ..).mpr
  exact .conjR_second _ _ (.here _ [])

theorem conjunctionBothR : BlockedR ((three (.conj (.bot : NormalForm Empty) .bot)).applyR
    (by change 2 ≤ 3; omega) _
      (SourceRules.conjR (constantRight [.bot,.conj .bot .bot]) (constantRight [.bot,.conj .bot .bot]))) := by
  apply ((three (.conj (.bot : NormalForm Empty) .bot)).blockedR_iff ..).mpr
  exact .conjR_both _ _ (.here _ []) (.here _ [])

theorem identical_binary_branches (l : Literal P) :
    (G.mix (G.identity l) (G.identity l)).branchSupport .left (two (.lit l)).selected = .both := rfl

def thinPremiseL (l : Literal P) := G.thinL [] [.lit l] [.lit l] (.lit l) (G.identity l)
def thinPremiseR (l : Literal P) := G.thinR [.lit l] [] [.lit l] (.lit l) (G.identity l)
def unblockedL (l : Literal P) := G.contractL (.lit l) [[],[]] [] [.lit l] (Nat.le_refl 2) (thinPremiseL l)
def unblockedR (l : Literal P) := G.contractR [.lit l] (.lit l) [[],[]] [] (Nat.le_refl 2) (thinPremiseR l)

theorem thin_not_blockedL (l : Literal P) : ¬ BlockedL (unblockedL l) := by
  intro h
  have h' := blockedSelectionL_head h
  cases h'

theorem thin_not_blockedR (l : Literal P) : ¬ BlockedR (unblockedR l) := by
  intro h
  have h' := blockedSelectionR_head h
  cases h'

def siteL (l : Literal P) : ContractionSite (unblockedL l) .left (.lit l) :=
  ⟨_,_,unblockedL l,.root,.here (.lit l) [],.left (.lit l) [[],[]] [] [.lit l] (Nat.le_refl 2) (thinPremiseL l)⟩
def siteR (l : Literal P) : ContractionSite (unblockedR l) .right (.lit l) :=
  ⟨_,_,unblockedR l,.root,.here (.lit l) [],.right [.lit l] (.lit l) [[],[]] [] (Nat.le_refl 2) (thinPremiseR l)⟩

theorem reducible_right (l : Literal P) : ReducibleRight (G.identity l) (unblockedL l) (siteL l) where
  topmost := ⟨rfl,rfl⟩
  tied := by
    refine ⟨?_,(siteL l).contraction⟩
    exact ((unblockedL l).cluster_correct .left (.here (.lit l) []) _).mpr (.root _)
  unblocked := thin_not_blockedL l
  ancestors := by
    intro b _ hp
    have h := b.proper_path_length (siteL l) hp
    change b.address.path.length < 0 at h
    omega

theorem reducible_left (l : Literal P) : ReducibleLeft (unblockedR l) (G.identity l) (siteR l) where
  topmost := ⟨rfl,rfl⟩
  tied := by
    refine ⟨?_,(siteR l).contraction⟩
    exact ((unblockedR l).cluster_correct .right (.here (.lit l) []) _).mpr (.root _)
  unblocked := thin_not_blockedR l
  ancestors := by
    intro b _ hp
    have h := b.proper_path_length (siteR l) hp
    change b.address.path.length < 0 at h
    omega

theorem signed_reducible (p : P) :
    ReducibleRight (G.identity (.pos p)) (unblockedL (.pos p)) (siteL (.pos p)) ∧
    ReducibleLeft (unblockedR (.neg p)) (G.identity (.neg p)) (siteR (.neg p)) :=
  ⟨reducible_right _,reducible_left _⟩

theorem classification_empty_constants :
    Nonempty (ImmediateClassification
      (G.mix (constantLeft [.top]) (constantLeft [.top])) .left (two (.top : NormalForm Empty)).selected) :=
  ⟨(two (.top : NormalForm Empty)).classifyL (Nat.le_refl 2) _ _ (by rfl)⟩

theorem cut_excluded (l : Literal P) : ¬ (G.cut (G.identity l) (G.identity l)).CutFree :=
  G.cut_not_cutFree _ _

end DosenPetric.Reduced.Gentzen.BlockedExamples
